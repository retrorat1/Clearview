import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import shutil
import urllib2,urllib
import re
import extract
import downloader
import time
from addon.common.addon import Addon
from addon.common.net import Net
###THANK YOU TO THOSE THAT MADE THE BASE OF THIS WIZARD GREAT WORK###Based on Muckyducks wizard ###


USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
addon_id = 'plugin.video.clearviewwiz'
ADDON = xbmcaddon.Addon(id=addon_id)
AddonTitle="Clearview Wizard" 
net = Net()
U = ADDON.getSetting('User')
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/art/'))
VERSION = "0.0.1"
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
PATH = "Clearview Wizard"            
BASEURL = "http://clearstreamview.x10host.com"
H = 'http://'

#def INDEX():
#    addDir('Clearstreamview Ivue TV GUIDE','URL',2,ART+'ivuewizard.png',FANART,'')
#    setView('movies', 'MAIN')

def INDEX():
    addDir('INSTALL CLEARVIEW GUIDE',BASEURL+'/wizard/ivue/ClearviewT.zip',5,ART+'ivueinstall.jpg',FANART,'')
    addDir('INSTALL CLEARVIEW ADDONS FILE',BASEURL+'/wizard/ivue/addons.ini',171,ART+'addons.jpg',FANART,'')
    addDir('INSTALL CLEARVIEW SETTINGS FILE',BASEURL+'/wizard/ivue/settings.xml',17,ART+'settings.jpg',FANART,'')
    addDir('RESET IVUE TV GUIDE DATABASE','url',18,ART+'reset.jpg',FANART,'')
    setView('movies', 'MAIN')

#################################
###  Clearstreamview Ivue  Maintenance ###
#################################

def CUSTOMSET(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Clearview Wizard", '                               Install ADDON Settings'):
        print '###'+AddonTitle+' - CUSTOM ADDON SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.clearview',''))
        advance=os.path.join(path, 'settings.xml')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== Clearview Wizard - WRITING RECOMENDED    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding RECOMENDED Settings")  
    return
	
def CUSTOMSET1(url,name):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Clearview Wizard", '                               Install ADDON Settings'):
        print '###'+AddonTitle+' - CUSTOM ADDON SETTINGS###'
        path = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.clearview',''))
        advance=os.path.join(path, 'addons.ini')
        link=net.http_GET(url).content
        a = open(advance,"w") 
        a.write(link)
        a.close()
        print '=== Clearview Wizard - WRITING RECOMENDED    '+str(advance)+'    ==='
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "                               Done Adding RECOMENDED Settings")  
    return


def DELETEIVUEDB():
    try:
        ivuepath = xbmc.translatePath(os.path.join('special://masterprofile/addon_data/script.clearview',''))
        if os.path.exists(ivuepath)==True:
            dialog = xbmcgui.Dialog()
            if dialog.yesno("Clearview Wizard", "                               Delete Ivue TV Guide Database"):
                ivuesource = os.path.join(ivuepath,"source.db")
                os.unlink(ivuesource)               
        dialog.ok("Clearview Wizard", "                                     IVUE Database has been Reset")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok(AddonTitle, "               Error Deleting Database or No Database file exists")
    return

#################################
###  Clearview Maintenance  ###
#################################

def WIZARD(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    dp = xbmcgui.DialogProgress()
    dp.create("Clearview Wizard","Downloading ",'', 'Please Wait')
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib, dp)
    addonfolder = xbmc.translatePath(os.path.join('special://','home'))
    time.sleep(2)
    dp.update(0,"", "Extracting Zip Please Wait")
    print '======================================='
    print addonfolder
    print '======================================='
    extract.all(lib,addonfolder,dp)
    dialog = xbmcgui.Dialog()
    dialog.ok("Clearview Wizard", "Please restart kodi//xbmc for changes To Take Effect","[COLOR yellow]Brought To You By Clearview Wizard[/COLOR]")

        
def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
          
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

N = base64.decodestring('')
T = base64.decodestring('L2FkZG9ucy50eHQ=')
B = base64.decodestring('')
F = base64.decodestring('')
def addDir(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        if mode==5 :
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        else:
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
                      
params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
        
        
print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
        
        
if mode==None or url==None or len(url)<1:
        INDEX()

elif mode==1:
        REPOMAINTENANCE()

elif mode==2:
        CUSTOMIVUE()

elif mode==5:
        WIZARD(name,url,description)
		
elif mode==17:
        CUSTOMSET(url,name)
		
elif mode==171:
        CUSTOMSET1(url,name)

elif mode==18:
        DELETEIVUEDB()
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
